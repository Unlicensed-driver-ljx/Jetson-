#!/bin/bash
# Mount the SSD as /mnt
#sudo mount /dev/nvme0n1p1 /mnt
sudo mkfs.ext4 /dev/mmcblk1

sudo parted /dev/mmcblk1 mklabel gpt
sleep 1
sudo parted /dev/mmcblk1 mkpart primary 0GB 100%
sleep 2
sudo mkfs.ext4 /dev/mmcblk1p1

sudo mount /dev/mmcblk1p1 /mnt

# Copy over the rootfs from the SD card to the SSD
sudo rsync -axHAWX --numeric-ids --info=progress2 --exclude={"/dev/","/proc/","/sys/","/tmp/","/run/","/mnt/","/media/*","/lost+found"} / /mnt
# We want to keep the SSD mounted for further operations
# So we do not unmount the SSD
