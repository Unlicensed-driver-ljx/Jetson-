# rootOnNVMe rootOneMMC rootOnSD emmc和sd卡的节点名一样,NVME启动只要将当前文件夹内涉及到mmcblk1的几个文件替换为nvme0n1即可，例如/dev/mmcblk1改为/dev/nvme0n1 /dev/mmcblk1p1改为nvme0n1p1 

Switch the rootfs to a NVMe SSD on the Jetson Xavier NX and Jetson AGX Xavier

These scripts install a service which runs at startup to point the rootfs to a SSD installed on /dev/nvme0 (the M.2 Key M slot).

This is taken from the NVIDIA Jetson AGX Xavier forum https://forums.developer.nvidia.com/t/how-to-boot-from-nvme-ssd/65147/22, written by user crazy_yorik (https://forums.developer.nvidia.com/u/crazy_yorick). Thank you crazy_yorik!

This procedure should be done on a fresh install of the SD card using JetPack 4.3版本以后都可以到5.0.2目前都已经测试过. Install the SSD into the M.2 Key M slot of the Jetson, and format it gpt, ext4, and setup a partition (p1). The AGX Xavier uses eMMC, the Xavier NX uses a SD card in the boot sequence.

Next, copy the rootfs of the eMMC/SD card to the SSD
```
$ ./copy-rootfs-ssd.sh
```

Then, setup the service. This will copy the .service file to the correct location, and install a startup script to set the rootfs to the SSD or EMMC.
```
$ ./setup-service.sh


以上步骤是你第一次安装了系统直接设置成外置存储启动的方法。然而当你配置完环境想要设置成多个设备外部启动，下面提供了设置外部启动安装配置完镜像捞取以后恢复设置成emmc启动的脚本，前提你还是要先刷一个系统到核心模组上面，然后注意BSP版本的对应！！

镜像备份的方法如下：

$ sudo dd if=/dev/mmcblk1p1 of=/硬盘挂载的绝对路径/system.img.raw bs=1M

$ cat /etc/nv_tegra_release 版本查看

捞取的镜像版本和你刷机的版本一致以后就继续操作下面的脚本，设置镜像恢复到外置emmc上启动,注意要将脚本和捞取的镜像system.img.raw放到硬盘路径下的同一个目录


$ ./Mirror_recovery.sh

Then, setup the service. This will copy the .service file to the correct location, and install a startup script to set the rootfs to the SSD or EMMC.

$ cd /home/nvidia/rootOnNVMe-master

$ ./setup-service.sh

```

After setting up the service, reboot for the changes to take effect.

### Boot Notes
These script changes the rootfs to the SSD after the kernel image is loaded from the eMMC/SD card. For the Xavier NX, you will still need to have the SD card installed for booting. As of this writing, the default configuration of the Jetson NX does not allow direct booting from the NVMe.

### Upgrading
Once this service is installed, the rootfs will be on the SSD. If you upgrade to a newer version of L4T using OTA updates (using the NVIDIA .deb repository), you will need to also apply those changes to the SD card that you are booting from.

Typically this involves copying the /boot* directory and /lib/modules/\<kernel name\>/ from the SSD to the SD card. If they are different, then modules load will be 'tainted', that is, the modules version will not match the kernel version.


## Notes
* Initial Release, May 2022/12/12
* JetPack 4.4 DP 4.5 4.6 4.6.1 4.6.2 5.0.2 都可以用
* Tested on Jetson Xavier NX ，Xavier 其他两个nano或者tx2你可以试试，感觉也是可以的

