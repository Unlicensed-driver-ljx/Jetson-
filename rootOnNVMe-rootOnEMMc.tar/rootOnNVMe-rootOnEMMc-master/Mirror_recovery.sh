#!/bin/bash

echo 125 | sudo tee /sys/devices/pwm-fan/target_pwm

sleep 3
sudo parted /dev/mmcblk1 mklabel gpt
sleep 3
sudo parted /dev/mmcblk1 mkpart primary 0GB 100%
sleep 3
sudo mkfs.ext4 /dev/mmcblk1p1
sleep 3

sudo mkdir -p /media/nvidia/ljx_emmc_system

sudo mount /dev/mmcblk1p1 /media/nvidia/ljx_emmc_system

sudo mount ./system.img.raw /mnt

sudo cp -a /mnt/* /media/nvidia/ljx_emmc_system && sync

sleep 6

sudo umount /media/nvidia/ljx_emmc_system
 
#sudo umount /mnt
sleep 1
#sudo rm -r /media/nvidia/glb_emmc_system

#sudo sed -i '10s/mmcblk0p1/mmcblk1p1/' /boot/extlinux/extlinux.conf

#reboot
#sudo mv /boot/extlinux/extlinux.conf /boot/extlinux/extlinux.conf.back

#sudo cp ./extlinux.conf /boot/extlinux/extlinux.conf


